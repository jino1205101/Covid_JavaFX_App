package com.example.covid;

import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class TimelineController {
    //Field
    @FXML
    private Button informationBtn;
    @FXML
    private Button logoutBtn;


}
