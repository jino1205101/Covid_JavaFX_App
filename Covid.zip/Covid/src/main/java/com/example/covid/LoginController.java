package com.example.covid;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class LoginController implements Initializable {

    //Field
    @FXML
    private ImageView brandingImageView;
    @FXML
    private ImageView lockImageView;
    @FXML
    private Button cancelBtn;
    @FXML
    private Label loginMessage;
    @FXML
    private TextField usernameField;
    @FXML
    private PasswordField passwordField;

    private FileInputStream fileInputStream = null;
    private ObjectInputStream objectInputStream = null;
    private SwitchScene switchScene;
    private Account account;

    //Override Method
    public void initialize(URL url, ResourceBundle resourceBundle){
        File brandingFile = new File("Pic/1.jpg");
        Image brandingImage = new Image(brandingFile.toURI().toString());
        brandingImageView.setImage(brandingImage);

        File lockFile = new File("Pic/2.jpg");
        Image lockImage = new Image(lockFile.toURI().toString());
        lockImageView.setImage(lockImage);
    }

    //Method
    public void loginBtnOnAction(ActionEvent event) throws IOException {
        if(usernameField.getText().isBlank() == false && passwordField.getText().isBlank() == false && validateLogin()){
            switchSceneToHome(event);
        }else {
            loginMessage.setText("Please enter username and password");
        }
    }

    public void cancelBtnOnAction(ActionEvent event){
        Stage stage = (Stage) cancelBtn.getScene().getWindow();
        stage.close();
    }

    public boolean validateLogin(){
        boolean check = false;
        try{
            fileInputStream = new FileInputStream("File/account.txt");
            objectInputStream = new ObjectInputStream(fileInputStream);
            ArrayList<Account> accounts = (ArrayList<Account>) objectInputStream.readObject();
            for(int i = 0 ; i < accounts.size() ; i++) {
                String username = accounts.get(i).getUsername();
                String password = accounts.get(i).getPassword();
                if( ((usernameField.getText()).equals(username)) && ((passwordField.getText()).equals(password)) ) {
                    account = accounts.get(i);
                    check = true;
                    loginMessage.setText("");
                    break;
                } else {
                    check = false;
                    loginMessage.setText("Invalid Login. Please try again.");
                }
            }
        }catch(Exception e) {
            e.printStackTrace();
            e.getCause();
        }
        return check;
    }

    public void switchSceneToRegister(ActionEvent event) throws IOException {
        switchScene = new SwitchScene();
        switchScene.switchToRegister(event);
    }

    public void switchSceneToHome(ActionEvent event) throws IOException{
        switchScene = new SwitchScene();
        switchScene.switchToHome(event);
    }
}