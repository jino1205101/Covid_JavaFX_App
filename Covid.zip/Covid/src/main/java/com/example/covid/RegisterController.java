package com.example.covid;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class RegisterController implements Initializable {
    //Field
    ObservableList<String> vaccinationsList = FXCollections.observableArrayList("0", "1", "2", "3", "4");
    ObservableList<String> bloodTypeList = FXCollections.observableArrayList("A", "B", "O", "AB");

    @FXML
    private ImageView verifyImageView;
    @FXML
    private Button closeBtn;
    @FXML
    private Label registrationMessage;
    @FXML
    private PasswordField setPasswordField;
    @FXML
    private PasswordField confirmPasswordField;
    @FXML
    private Label confirmPasswordMessage;
    @FXML
    private Label usernameMessage;
    @FXML
    private TextField firstnameField;
    @FXML
    private TextField lastnameField;
    @FXML
    private TextField usernameField;
    @FXML
    private DatePicker birthDate;
    @FXML
    private TextField telephoneNumberField;
    @FXML
    private RadioButton genderMaleRadioButton;
    @FXML
    private RadioButton genderFemaleRadioButton;
    @FXML
    private ChoiceBox vaccinationsChoiceBox;
    @FXML
    private ChoiceBox bloodTypeChoiceBox;
    @FXML
    private Label telephoneNumberLabel;
    @FXML
    private Label errorMessage;
    @FXML
    private CheckBox infectedCheckbox;

    private String gender;

    private FileOutputStream fileOutputStream;
    private ObjectOutputStream objectOutputStream;
    private FileInputStream fileInputStream;
    private ObjectInputStream objectInputStream;

    //Override Method
    public void initialize(URL url, ResourceBundle resourceBundle){
        File verifyFile = new File("Pic/3.png");
        Image verifyImage = new Image(verifyFile.toURI().toString());
        verifyImageView.setImage(verifyImage);

        vaccinationsChoiceBox.setItems(vaccinationsList);
        bloodTypeChoiceBox.setItems(bloodTypeList);
    }

    //Method
    public void closeBtnOnAction(ActionEvent event){
        Stage stage = (Stage) closeBtn.getScene().getWindow();
        stage.close();
    }

    public void registerBtnOnAction(ActionEvent event){
        if(setPasswordField.getText().equals(confirmPasswordField.getText())){
            registerAccount();
            confirmPasswordMessage.setText("");
        }else {
            confirmPasswordMessage.setText("Password does not match");
        }
    }

    public void registerAccount(){
        String firstname = firstnameField.getText();
        String lastname = lastnameField.getText();
        String username = usernameField.getText();
        String password = setPasswordField.getText();
        LocalDate birthday = birthDate.getValue();
        String telephoneNumber = telephoneNumberField.getText();
        int vaccinations = 1;
        String bloodType = bloodTypeChoiceBox.getTypeSelector();
        boolean infected = checkInfected();

        try {
            fileInputStream = new FileInputStream("File/account.txt");
            objectInputStream = new ObjectInputStream(fileInputStream);
            @SuppressWarnings("unchecked")
            ArrayList<Account> accounts = (ArrayList<Account>) objectInputStream.readObject();
            if(checkCondition()) {
                Account account = new Account(firstname, lastname, username, password, gender, telephoneNumber, bloodType, vaccinations, birthday, infected);
                accounts.add(account);
                fileOutputStream = new FileOutputStream("File/account.txt");
                objectOutputStream = new ObjectOutputStream(fileOutputStream);
                objectOutputStream.writeObject(accounts);
                registrationMessage.setText("User has been registered successfully!");
            }
        }catch(EOFException e){
            try {
                ArrayList<Account> accounts = new ArrayList<Account>();
                if(checkCondition()) {
                    Account account = new Account(firstname, lastname, username, password, gender, telephoneNumber, bloodType, vaccinations, birthday, infected);
                    accounts.add(account);
                    fileOutputStream = new FileOutputStream("File/account.txt");
                    objectOutputStream = new ObjectOutputStream(fileOutputStream);
                    objectOutputStream.writeObject(accounts);
                    registrationMessage.setText("User has been registered successfully!");
                }
            } catch (Exception e1) {
                e1.printStackTrace();
                e1.getCause();
            }
        }catch (Exception e) {
            e.printStackTrace();
            e.getCause();
        }
    }

    public boolean checkConditionUsername(){
        boolean condition = true;
        try {
            fileInputStream = new FileInputStream("File/account.txt");
            objectInputStream = new ObjectInputStream(fileInputStream);
            @SuppressWarnings("unchecked")
            ArrayList<Account> accounts = (ArrayList<Account>) objectInputStream.readObject();
            for (int i = 0; i < accounts.size(); i++) {
                if (usernameField.getText().equals(accounts.get(i).getUsername())) {
                    condition = false;
                    usernameMessage.setText("This username is already taken");
                    break;
                }
            }
            fileInputStream.close();
            objectInputStream.close();
        } catch (EOFException e){
            usernameMessage.setText("");
            condition = true;
        } catch (Exception e){
            condition = false;
        }
        return condition;
    }

    public boolean checkConditionGender(){
        if (genderFemaleRadioButton.isSelected() && genderMaleRadioButton.isSelected()){
            return false;
        }
        else if(genderFemaleRadioButton.isSelected() || genderMaleRadioButton.isSelected()){
            checkGender();
            return true;
        }
        else {
            return false;
        }
    }

    public void checkGender(){
        if (genderMaleRadioButton.isSelected()){
            gender = "Male";
        }
        else {
            gender = "Female";
        }
    }

    public boolean checkInfected(){
        if(infectedCheckbox.isSelected()){
            return true;
        }
        else{
            return false;
        }
    }

    public boolean checkFieldEmpty(){
        if(firstnameField.getText().isBlank()==true || lastnameField.getText().isBlank()==true || telephoneNumberField.getText().isBlank()==true || usernameField.getText().isBlank()==true || setPasswordField.getText().isBlank()==true){
            return false;
        } else{
          return true;
        }
    }

    public boolean checkCondition(){
        if (checkConditionUsername() && checkConditionGender() && checkFieldEmpty()){
            errorMessage.setText("");
            return true;
        }
        else {
            errorMessage.setText("Please check your information again");
            return false;
        }
    }
}
