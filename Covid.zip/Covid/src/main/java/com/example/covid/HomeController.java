package com.example.covid;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class HomeController {
    //Field
    @FXML
    private Button timelineBtn;
    @FXML
    private Button logoutBtn;

    public void createTimelineFrom(){
        try{
            FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("timeline.fxml"));
            Stage timelineStage = new Stage();
            timelineStage.initStyle(StageStyle.UNDECORATED);
            Scene scene = new Scene(fxmlLoader.load(), 1080, 720);
            timelineStage.setTitle("Covid-19");
            timelineStage.setScene(scene);
            timelineStage.show();
        }catch (Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
