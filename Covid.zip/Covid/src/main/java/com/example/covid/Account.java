package com.example.covid;

import java.io.Serializable;
import java.time.LocalDate;

public class Account implements Serializable {
    //Field
    private static final long serialVersionUID = 1L;

    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private String gender;
    private String telephoneNumber;
    private String bloodType;
    private int vaccinations;
    private LocalDate birthdate;
    private boolean infected;

    //Constructor
    Account(){}
    Account(String firstname, String lastname, String username, String password, String gender, String telephoneNumber, String bloodType, int vaccinations, LocalDate birthdate, boolean infected){
        this.firstname = firstname;
        this.lastname = lastname;
        this.username = username;
        this.password = password;
        this.gender = gender;
        this.telephoneNumber = telephoneNumber;
        this.bloodType = bloodType;
        this.vaccinations = vaccinations;
        this.birthdate = birthdate;
        this.infected = infected;
    }

    //Access Method
    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
    public String getGender() {
        return gender;
    }
    public void setGender(String gender) {
        this.gender = gender;
    }
    public String getTelephoneNumber() {
        return telephoneNumber;
    }
    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }
    public String getBloodType() {
        return bloodType;
    }
    public void setBloodType(String bloodType) {
        this.bloodType = bloodType;
    }
    public int getVaccinations() {
        return vaccinations;
    }
    public void setVaccinations(int vaccinations) {
        this.vaccinations = vaccinations;
    }
    public LocalDate getBirthdate() {
        return birthdate;
    }
    public void setBirthdate(LocalDate birthdate) {
        this.birthdate = birthdate;
    }
    public boolean isInfected() {
        return infected;
    }
    public void setInfected(boolean infected) {
        this.infected = infected;
    }
}
